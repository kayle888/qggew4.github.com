/*-------------------------响应函数自执行------------------------------*/
var test = 0; //解决压缩bug
(function (doc, win) {
    var docEl = doc.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            if (100 * (clientWidth / 1920) < 66) {
                docEl.style.fontSize = '66px';
            } else {
                docEl.style.fontSize = 100 * (clientWidth / 1920) + 'px';
            }
        };
    if (!doc.addEventListener) return;
    win.addEventListener(resizeEvt, recalc, false);
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);
/*---------------------------合作伙伴切换----------------------------*/
setInterval(function () {
    $(".title_word").find(".disNone").removeClass("disNone").siblings().addClass("disNone");
}, 3000);
/*----------------------显示优惠内容---------------------*/
$(".look_pro,.pro_img").on("click", function () {
    $(this).siblings(".light_box").removeClass("disNone");
    $("body").addClass("overHiden");
});
/*----------------------关闭优惠内容---------------------*/
$(".close_btn").on("click", function () {
    $(this).parents(".light_box").addClass("disNone");
    $("body").removeClass("overHiden");
});
/*----------------------v4---------------------*/
function openUrl(flag) {
    // var items = ['0715623'];
    var item = items[Math.floor(Math.random() * items.length)];
    if (flag) {
        window.open(pcUrl + '/?i_code=' + item);
    } else {
        window.open(pcUrl + '/register?i_code=' + item);
    }
}

function appUrl() {
    var item = items[Math.floor(Math.random() * items.length)];
    window.open(downloadUrl + '/?i_code=' + item);
}
